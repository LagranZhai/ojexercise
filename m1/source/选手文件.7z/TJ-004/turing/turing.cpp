#include<bits/stdc++.h>
using namespace std;
int n,a,b,x1,x2,y1,y2,z1,z2,A[100][100],B[100][100],C[100][100];
int main(){
    freopen("turing.in","r",stdin);
    freopen("turing.out","w",stdout);
    cout<<"0";
    return 0;
}