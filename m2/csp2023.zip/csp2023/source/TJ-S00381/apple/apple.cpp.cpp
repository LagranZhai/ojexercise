#include<bits/stdc++.h>
using namespace std;
int n,k,arr[500005],apple[500005];
bool vis[500005];
int main(){
	cin>>a>>k;
	for(int i=0;i<n;i++){
		cin>>arr[i];
	}
	for(int i=0;i<n;i++){
		
	}
	
	return 0;
}
