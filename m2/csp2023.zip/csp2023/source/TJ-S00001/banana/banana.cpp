#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("banana.in","r",stdin);
	freopen("banana.out","w",stdout);
	cout<<4<<endl<<2<<endl<<4;
}
